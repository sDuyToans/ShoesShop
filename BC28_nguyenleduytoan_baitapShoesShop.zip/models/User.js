export default class User{
    email = '';
    password = '';
    name = '';
    gender = true;
    phone = '';
}
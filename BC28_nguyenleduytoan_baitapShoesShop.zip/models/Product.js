export default class Product {
  id = "";
  name = "";
  alias = "";
  price = "";
  description = "";
  image = "";
  deleted = "";
  shortDescription = "";
  deleted = "";
  size = [];
  quantity = "";
  categories = [];
  relatedProducts = [];
  dateTime = "";
}
